package com.smartkids.learning;

import android.app.Activity;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Locale;

public class MainActivity extends Activity {
    WebView web;
    TextToSpeech tts;

    class Bridge {
        @JavascriptInterface
        public void speak(String text, String lang) {
            if (tts == null) return;
            tts.setLanguage(Locale.forLanguageTag(lang));
            tts.setSpeechRate(0.8f);
            tts.setPitch(1.2f);
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u");
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        tts = new TextToSpeech(this, status -> { });
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.addJavascriptInterface(new Bridge(), "AndroidTTS");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){var h=document.querySelector('.bar h2'),b=document.querySelector('.b0');if(b&&h&&h.textContent.indexOf('হ্যালো')<0){b.click();return 1}return 0})()",
            v -> { if (!"1".equals(v)) finish(); });
    }

    @Override
    protected void onDestroy() {
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
